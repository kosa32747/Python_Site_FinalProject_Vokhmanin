from django.contrib.auth import views as auth_views
from django.urls import path

from . import views

urlpatterns = [
    path('', views.home, name='home'),
    path('ads/<int:pk>/', views.ad_detail, name='ad_detail'),
    path('ads/create/', views.create_ad, name='create_ad'),
    path('ads/<int:pk>/edit/', views.edit_ad, name='edit_ad'),
    path('ads/<int:pk>/delete/', views.delete_ad, name='delete_ad'),
    path('ads/<int:pk>/review/', views.add_review, name='add_review'),
    path('my/', views.my_ads, name='my_ads'),
    path('moderation/', views.moderation_queue, name='moderation_queue'),
    path('register/', views.register, name='register'),
    path('login/', views.user_login, name='login'),
    path('logout/', auth_views.LogoutView.as_view(next_page='home'), name='logout'),
]
