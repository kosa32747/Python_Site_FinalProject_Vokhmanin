from django import forms
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User

from .models import Ad, Review


class RegistrationForm(UserCreationForm):
    """Регистрация: к стандартной форме Django добавлена обязательная почта."""

    email = forms.EmailField(required=True, label='E-mail')

    class Meta:
        model = User
        fields = ('username', 'email', 'password1', 'password2')

    def save(self, commit=True):
        user = super().save(commit=False)
        user.email = self.cleaned_data['email']
        if commit:
            user.save()
        return user


class AdForm(forms.ModelForm):
    """Создание и редактирование объявления.

    Поля owner и is_approved сюда намеренно не включены: владельца
    проставляет view по текущему пользователю, а одобрение выдаёт модератор.
    Иначе любой автор мог бы опубликовать объявление в обход модерации.
    """

    class Meta:
        model = Ad
        fields = [
            'title',
            'description',
            'price',
            'location',
            'contact_info',
            'categories',
            'image',
            'available_from',
            'available_to',
        ]
        widgets = {
            'description': forms.Textarea(attrs={'rows': 5}),
            'available_from': forms.DateInput(attrs={'type': 'date'}),
            'available_to': forms.DateInput(attrs={'type': 'date'}),
            'categories': forms.CheckboxSelectMultiple(),
        }

    def clean(self):
        """Проверяем, что дата окончания аренды не раньше даты начала."""
        cleaned = super().clean()
        start = cleaned.get('available_from')
        end = cleaned.get('available_to')
        if start and end and end < start:
            raise forms.ValidationError(
                'Дата окончания аренды не может быть раньше даты начала.'
            )
        return cleaned


class AdSearchForm(forms.Form):
    """Фильтры поиска. Все поля необязательные — пустая форма показывает всё."""

    q = forms.CharField(
        required=False,
        label='Ключевые слова',
        widget=forms.TextInput(attrs={'placeholder': 'Поиск по заголовку и описанию'}),
    )
    location = forms.CharField(
        required=False,
        label='Местоположение',
        widget=forms.TextInput(attrs={'placeholder': 'Город или район'}),
    )
    price_min = forms.DecimalField(required=False, min_value=0, label='Цена от')
    price_max = forms.DecimalField(required=False, min_value=0, label='Цена до')

    def clean(self):
        cleaned = super().clean()
        price_min = cleaned.get('price_min')
        price_max = cleaned.get('price_max')
        if price_min is not None and price_max is not None and price_max < price_min:
            raise forms.ValidationError('«Цена до» не может быть меньше «цены от».')
        return cleaned


class ReviewForm(forms.ModelForm):
    """Отзыв об объявлении и продавце."""

    class Meta:
        model = Review
        fields = ['rating', 'text']
        widgets = {
            'rating': forms.RadioSelect(),
            'text': forms.Textarea(attrs={'rows': 4}),
        }
