"""Unit-тесты по пункту 7 ТЗ.

Покрыты все шесть обязательных функций: размещение объявления, поиск
с фильтрами, редактирование и удаление с проверкой авторства,
аутентификация, модерация и отзывы.
"""

from decimal import Decimal

from django.contrib.auth.models import User
from django.test import TestCase
from django.urls import reverse

from .forms import AdForm, AdSearchForm, RegistrationForm
from .models import Ad, Review


class BaseTestData(TestCase):
    """Общие данные для всех тестов: два пользователя и модератор."""

    @classmethod
    def setUpTestData(cls):
        cls.owner = User.objects.create_user('owner', password='StrongPass123!')
        cls.other = User.objects.create_user('other', password='StrongPass123!')
        cls.moderator = User.objects.create_user(
            'moderator', password='StrongPass123!', is_staff=True
        )
        cls.ad = Ad.objects.create(
            owner=cls.owner,
            title='Вечернее платье',
            description='Длинное чёрное платье, размер M',
            price=Decimal('1500.00'),
            location='Москва',
            contact_info='+7 900 000-00-00',
            is_approved=True,
        )
        cls.pending_ad = Ad.objects.create(
            owner=cls.owner,
            title='Смокинг',
            description='Классический смокинг, размер 48',
            price=Decimal('2500.00'),
            location='Санкт-Петербург',
            contact_info='mail@example.com',
            is_approved=False,
        )


class AdModelTest(BaseTestData):
    def test_new_ad_is_not_approved_by_default(self):
        ad = Ad.objects.create(
            owner=self.owner,
            title='Пальто',
            description='Шерстяное пальто',
            price=Decimal('900.00'),
            location='Казань',
            contact_info='@user',
        )
        self.assertFalse(ad.is_approved)

    def test_str_returns_title(self):
        self.assertEqual(str(self.ad), 'Вечернее платье')

    def test_average_rating_without_reviews_is_none(self):
        self.assertIsNone(self.ad.average_rating)

    def test_average_rating_is_calculated(self):
        Review.objects.create(ad=self.ad, author=self.other, rating=4, text='Хорошо')
        Review.objects.create(ad=self.ad, author=self.moderator, rating=5, text='Отлично')
        self.assertEqual(self.ad.average_rating, 4.5)


class AdFormTest(TestCase):
    def test_form_requires_price_location_and_contacts(self):
        """Обязательные по ТЗ поля не должны проходить валидацию пустыми."""
        form = AdForm(data={'title': 'Платье', 'description': 'Описание'})
        self.assertFalse(form.is_valid())
        self.assertIn('price', form.errors)
        self.assertIn('location', form.errors)
        self.assertIn('contact_info', form.errors)

    def test_valid_form(self):
        form = AdForm(data={
            'title': 'Платье',
            'description': 'Описание',
            'price': '1200.00',
            'location': 'Москва',
            'contact_info': '+7 900 111-11-11',
        })
        self.assertTrue(form.is_valid(), form.errors)

    def test_end_date_before_start_date_is_rejected(self):
        form = AdForm(data={
            'title': 'Платье',
            'description': 'Описание',
            'price': '1200.00',
            'location': 'Москва',
            'contact_info': '+7 900 111-11-11',
            'available_from': '2026-05-10',
            'available_to': '2026-05-01',
        })
        self.assertFalse(form.is_valid())


class SearchTest(BaseTestData):
    """Пункт 2 ТЗ: поиск по ключевым словам, местоположению и цене."""

    def test_search_by_keyword(self):
        response = self.client.get(reverse('home'), {'q': 'платье'})
        self.assertContains(response, 'Вечернее платье')

    def test_search_by_keyword_excludes_others(self):
        Ad.objects.create(
            owner=self.owner, title='Куртка', description='Зимняя',
            price=Decimal('800.00'), location='Москва',
            contact_info='x', is_approved=True,
        )
        response = self.client.get(reverse('home'), {'q': 'куртка'})
        self.assertNotContains(response, 'Вечернее платье')

    def test_filter_by_location(self):
        response = self.client.get(reverse('home'), {'location': 'Казань'})
        self.assertNotContains(response, 'Вечернее платье')

    def test_filter_by_price_range(self):
        response = self.client.get(reverse('home'), {'price_min': '2000'})
        self.assertNotContains(response, 'Вечернее платье')

    def test_price_max_lower_than_min_is_invalid(self):
        form = AdSearchForm(data={'price_min': '2000', 'price_max': '1000'})
        self.assertFalse(form.is_valid())

    def test_unapproved_ads_are_hidden_from_list(self):
        """Пункт 5 ТЗ: до модерации объявление не показывается в выдаче."""
        response = self.client.get(reverse('home'))
        self.assertNotContains(response, 'Смокинг')


class AuthenticationTest(BaseTestData):
    """Пункт 4 ТЗ: аутентификация и доступ к контактам."""

    def test_registration_form_is_valid(self):
        form = RegistrationForm(data={
            'username': 'newuser',
            'email': 'new@example.com',
            'password1': 'StrongPassword123!',
            'password2': 'StrongPassword123!',
        })
        self.assertTrue(form.is_valid(), form.errors)

    def test_anonymous_cannot_create_ad(self):
        response = self.client.get(reverse('create_ad'))
        self.assertEqual(response.status_code, 302)
        self.assertIn(reverse('login'), response.url)

    def test_anonymous_does_not_see_contacts(self):
        response = self.client.get(reverse('ad_detail', args=[self.ad.pk]))
        self.assertNotContains(response, '+7 900 000-00-00')

    def test_authenticated_user_sees_contacts(self):
        self.client.login(username='other', password='StrongPass123!')
        response = self.client.get(reverse('ad_detail', args=[self.ad.pk]))
        self.assertContains(response, '+7 900 000-00-00')


class AdOwnershipTest(BaseTestData):
    """Пункт 3 ТЗ: редактировать и удалять можно только свои объявления."""

    def test_owner_can_edit(self):
        self.client.login(username='owner', password='StrongPass123!')
        response = self.client.get(reverse('edit_ad', args=[self.ad.pk]))
        self.assertEqual(response.status_code, 200)

    def test_stranger_cannot_edit(self):
        self.client.login(username='other', password='StrongPass123!')
        response = self.client.get(reverse('edit_ad', args=[self.ad.pk]))
        self.assertEqual(response.status_code, 403)

    def test_stranger_cannot_delete(self):
        self.client.login(username='other', password='StrongPass123!')
        response = self.client.post(reverse('delete_ad', args=[self.ad.pk]))
        self.assertEqual(response.status_code, 403)
        self.assertTrue(Ad.objects.filter(pk=self.ad.pk).exists())

    def test_owner_can_delete(self):
        self.client.login(username='owner', password='StrongPass123!')
        response = self.client.post(reverse('delete_ad', args=[self.ad.pk]))
        self.assertEqual(response.status_code, 302)
        self.assertFalse(Ad.objects.filter(pk=self.ad.pk).exists())

    def test_created_ad_gets_current_user_as_owner(self):
        self.client.login(username='other', password='StrongPass123!')
        self.client.post(reverse('create_ad'), {
            'title': 'Костюм',
            'description': 'Серый костюм',
            'price': '1100.00',
            'location': 'Самара',
            'contact_info': '@other',
        })
        ad = Ad.objects.get(title='Костюм')
        self.assertEqual(ad.owner, self.other)
        self.assertFalse(ad.is_approved)


class ModerationTest(BaseTestData):
    """Пункт 5 ТЗ: очередь модерации доступна только сотрудникам."""

    def test_anonymous_cannot_open_moderation(self):
        response = self.client.get(reverse('moderation_queue'))
        self.assertEqual(response.status_code, 302)

    def test_regular_user_cannot_open_moderation(self):
        self.client.login(username='other', password='StrongPass123!')
        response = self.client.get(reverse('moderation_queue'))
        self.assertEqual(response.status_code, 302)

    def test_moderator_can_approve(self):
        self.client.login(username='moderator', password='StrongPass123!')
        response = self.client.post(
            reverse('moderation_queue'), {'approved_ads': [self.pending_ad.pk]}
        )
        self.assertEqual(response.status_code, 302)
        self.pending_ad.refresh_from_db()
        self.assertTrue(self.pending_ad.is_approved)


class ReviewTest(BaseTestData):
    """Пункт 6 ТЗ: отзывы с рейтингом."""

    def test_user_can_leave_review(self):
        self.client.login(username='other', password='StrongPass123!')
        response = self.client.post(
            reverse('add_review', args=[self.ad.pk]),
            {'rating': 5, 'text': 'Всё отлично'},
        )
        self.assertEqual(response.status_code, 302)
        self.assertEqual(self.ad.reviews.count(), 1)

    def test_owner_cannot_review_own_ad(self):
        self.client.login(username='owner', password='StrongPass123!')
        response = self.client.post(
            reverse('add_review', args=[self.ad.pk]),
            {'rating': 5, 'text': 'Сам себя хвалю'},
        )
        self.assertEqual(response.status_code, 403)
        self.assertEqual(self.ad.reviews.count(), 0)

    def test_second_review_from_same_user_is_blocked(self):
        Review.objects.create(ad=self.ad, author=self.other, rating=3, text='Нормально')
        self.client.login(username='other', password='StrongPass123!')
        self.client.post(
            reverse('add_review', args=[self.ad.pk]),
            {'rating': 5, 'text': 'Передумал'},
        )
        self.assertEqual(self.ad.reviews.count(), 1)

    def test_anonymous_cannot_leave_review(self):
        response = self.client.get(reverse('add_review', args=[self.ad.pk]))
        self.assertEqual(response.status_code, 302)
