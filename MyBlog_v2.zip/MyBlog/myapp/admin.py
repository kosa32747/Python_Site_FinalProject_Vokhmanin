from django.contrib import admin

from .models import Ad, Category, Review


@admin.action(description='Одобрить выбранные объявления')
def approve_ads(modeladmin, request, queryset):
    """Массовое одобрение прямо из админки — дублирует страницу модерации."""
    queryset.update(is_approved=True)


@admin.register(Ad)
class AdAdmin(admin.ModelAdmin):
    list_display = ('title', 'owner', 'price', 'location', 'is_approved', 'created_at')
    list_filter = ('is_approved', 'location', 'categories')
    search_fields = ('title', 'description', 'location')
    autocomplete_fields = ('owner',)
    filter_horizontal = ('categories',)
    actions = [approve_ads]


@admin.register(Category)
class CategoryAdmin(admin.ModelAdmin):
    list_display = ('name',)
    search_fields = ('name',)


@admin.register(Review)
class ReviewAdmin(admin.ModelAdmin):
    list_display = ('ad', 'author', 'rating', 'created_at')
    list_filter = ('rating',)
    search_fields = ('text',)
