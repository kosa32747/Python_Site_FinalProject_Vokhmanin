from django.conf import settings
from django.core.validators import MaxValueValidator, MinValueValidator
from django.db import models
from django.urls import reverse


class Category(models.Model):
    """Категория одежды: платья, верхняя одежда, костюмы и т. д.

    По ТЗ объявление может относиться сразу к нескольким категориям,
    поэтому связь с Ad — «многие ко многим».
    """

    name = models.CharField('Название', max_length=100, unique=True)
    description = models.TextField('Описание', blank=True)

    class Meta:
        verbose_name = 'Категория'
        verbose_name_plural = 'Категории'
        ordering = ['name']

    def __str__(self):
        return self.name


class Ad(models.Model):
    """Объявление об аренде одежды.

    Ключевое изменение после код-ревью: у объявления появился владелец (owner).
    Без него невозможны сразу три функции из ТЗ — редактирование только своих
    объявлений, скрытие контактов от неавторизованных и отзывы о продавце.
    """

    owner = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name='ads',
        verbose_name='Владелец',
    )
    title = models.CharField('Заголовок', max_length=200)
    description = models.TextField('Описание')
    price = models.DecimalField(
        'Стоимость аренды в сутки, ₽',
        max_digits=10,
        decimal_places=2,
        validators=[MinValueValidator(0)],
    )
    location = models.CharField('Местоположение', max_length=200)
    contact_info = models.CharField(
        'Контактная информация',
        max_length=200,
        help_text='Телефон, почта или мессенджер. Виден только авторизованным пользователям.',
    )
    categories = models.ManyToManyField(
        Category,
        related_name='ads',
        verbose_name='Категории',
        blank=True,
    )
    image = models.ImageField('Фотография', upload_to='ads/%Y/%m/', blank=True)
    available_from = models.DateField('Доступно с', null=True, blank=True)
    available_to = models.DateField('Доступно по', null=True, blank=True)
    is_approved = models.BooleanField(
        'Прошло модерацию',
        default=False,
        help_text='Объявление появляется на сайте только после одобрения модератором.',
    )
    created_at = models.DateTimeField('Создано', auto_now_add=True)
    updated_at = models.DateTimeField('Обновлено', auto_now=True)

    class Meta:
        verbose_name = 'Объявление'
        verbose_name_plural = 'Объявления'
        ordering = ['-created_at']

    def __str__(self):
        return self.title

    def get_absolute_url(self):
        return reverse('ad_detail', args=[self.pk])

    @property
    def average_rating(self):
        """Средняя оценка продавца по этому объявлению.

        Возвращает None, если отзывов ещё нет, — шаблон тогда покажет прочерк.
        """
        result = self.reviews.aggregate(models.Avg('rating'))['rating__avg']
        return round(result, 1) if result is not None else None


class Review(models.Model):
    """Отзыв об объявлении и продавце с числовым рейтингом.

    Один пользователь оставляет не больше одного отзыва на объявление —
    это ограничение задано через UniqueConstraint в Meta.
    """

    RATING_CHOICES = [(i, str(i)) for i in range(1, 6)]

    ad = models.ForeignKey(
        Ad,
        on_delete=models.CASCADE,
        related_name='reviews',
        verbose_name='Объявление',
    )
    author = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name='reviews',
        verbose_name='Автор отзыва',
    )
    rating = models.PositiveSmallIntegerField(
        'Оценка',
        choices=RATING_CHOICES,
        validators=[MinValueValidator(1), MaxValueValidator(5)],
    )
    text = models.TextField('Текст отзыва')
    created_at = models.DateTimeField('Создан', auto_now_add=True)

    class Meta:
        verbose_name = 'Отзыв'
        verbose_name_plural = 'Отзывы'
        ordering = ['-created_at']
        constraints = [
            models.UniqueConstraint(
                fields=['ad', 'author'],
                name='unique_review_per_user_per_ad',
            )
        ]

    def __str__(self):
        return f'Отзыв {self.author} на «{self.ad}» — {self.rating}/5'
