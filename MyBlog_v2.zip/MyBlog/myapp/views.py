from django.contrib import messages
from django.contrib.auth import authenticate, login
from django.contrib.auth.decorators import login_required, user_passes_test
from django.db.models import Q
from django.http import HttpResponseForbidden
from django.shortcuts import get_object_or_404, redirect, render

from .forms import AdForm, AdSearchForm, RegistrationForm, ReviewForm
from .models import Ad


def _is_moderator(user):
    """Модератор — сотрудник (is_staff). Используется в декораторе ниже."""
    return user.is_authenticated and user.is_staff


def home(request):
    """Главная страница: список одобренных объявлений с поиском и фильтрами.

    Реализует пункт 2 ТЗ: поиск по ключевым словам, по местоположению
    и по диапазону стоимости аренды. Фильтры комбинируются между собой.
    """
    ads = Ad.objects.filter(is_approved=True).prefetch_related('categories')
    form = AdSearchForm(request.GET or None)

    if form.is_valid():
        q = form.cleaned_data.get('q')
        location = form.cleaned_data.get('location')
        price_min = form.cleaned_data.get('price_min')
        price_max = form.cleaned_data.get('price_max')

        if q:
            # Поиск по заголовку ИЛИ по тексту описания.
            ads = ads.filter(Q(title__icontains=q) | Q(description__icontains=q))
        if location:
            ads = ads.filter(location__icontains=location)
        if price_min is not None:
            ads = ads.filter(price__gte=price_min)
        if price_max is not None:
            ads = ads.filter(price__lte=price_max)

    return render(request, 'myapp/home.html', {'ads': ads, 'form': form})


def ad_detail(request, pk):
    """Страница объявления.

    Контакты продавца отдаются только авторизованным пользователям —
    это пункт 4 ТЗ: «только авторизованные могут просматривать
    контактную информацию». Проверка сделана здесь, а не в шаблоне,
    чтобы данные вообще не попадали в HTML для гостя.
    """
    ad = get_object_or_404(Ad, pk=pk)

    # Неодобренное объявление видят только его владелец и модератор.
    if not ad.is_approved and not (
        request.user == ad.owner or _is_moderator(request.user)
    ):
        return HttpResponseForbidden('Это объявление ещё не прошло модерацию.')

    context = {
        'ad': ad,
        'reviews': ad.reviews.select_related('author'),
        'can_see_contacts': request.user.is_authenticated,
        'can_edit': request.user == ad.owner,
        'review_form': ReviewForm() if request.user.is_authenticated else None,
        'already_reviewed': (
            request.user.is_authenticated
            and ad.reviews.filter(author=request.user).exists()
        ),
    }
    return render(request, 'myapp/ad_detail.html', context)


@login_required
def create_ad(request):
    """Создание объявления. Доступно только авторизованным (пункт 4 ТЗ)."""
    if request.method == 'POST':
        form = AdForm(request.POST, request.FILES)
        if form.is_valid():
            ad = form.save(commit=False)
            ad.owner = request.user  # владельца берём из сессии, а не из формы
            ad.is_approved = False   # всё новое уходит на модерацию (пункт 5 ТЗ)
            ad.save()
            form.save_m2m()          # нужно из-за commit=False и поля categories
            messages.success(
                request, 'Объявление отправлено на модерацию.'
            )
            return redirect('my_ads')
    else:
        form = AdForm()
    return render(request, 'myapp/ad_form.html', {'form': form, 'is_edit': False})


@login_required
def edit_ad(request, pk):
    """Редактирование своего объявления (пункт 3 ТЗ).

    Проверка авторства обязательна: без неё любой залогиненный пользователь
    мог бы править чужие объявления, подставив другой id в адресе.
    """
    ad = get_object_or_404(Ad, pk=pk)
    if ad.owner != request.user:
        return HttpResponseForbidden('Редактировать можно только свои объявления.')

    if request.method == 'POST':
        form = AdForm(request.POST, request.FILES, instance=ad)
        if form.is_valid():
            ad = form.save(commit=False)
            # После правки объявление снова уходит на модерацию,
            # иначе через редактирование можно обойти проверку.
            ad.is_approved = False
            ad.save()
            form.save_m2m()
            messages.success(request, 'Изменения сохранены, объявление отправлено на повторную модерацию.')
            return redirect('my_ads')
    else:
        form = AdForm(instance=ad)
    return render(request, 'myapp/ad_form.html', {'form': form, 'is_edit': True, 'ad': ad})


@login_required
def delete_ad(request, pk):
    """Удаление своего объявления (пункт 3 ТЗ).

    Удаление только по POST: по GET показываем страницу подтверждения.
    Удалять по GET-ссылке нельзя — её может открыть поисковый робот.
    """
    ad = get_object_or_404(Ad, pk=pk)
    if ad.owner != request.user:
        return HttpResponseForbidden('Удалять можно только свои объявления.')

    if request.method == 'POST':
        ad.delete()
        messages.success(request, 'Объявление удалено.')
        return redirect('my_ads')
    return render(request, 'myapp/ad_confirm_delete.html', {'ad': ad})


@login_required
def my_ads(request):
    """Личный кабинет: все объявления пользователя, включая неодобренные."""
    ads = Ad.objects.filter(owner=request.user).prefetch_related('categories')
    return render(request, 'myapp/my_ads.html', {'ads': ads})


@login_required
def add_review(request, pk):
    """Отзыв об объявлении и продавце с оценкой от 1 до 5 (пункт 6 ТЗ)."""
    ad = get_object_or_404(Ad, pk=pk, is_approved=True)

    if ad.owner == request.user:
        return HttpResponseForbidden('Нельзя оставить отзыв на собственное объявление.')
    if ad.reviews.filter(author=request.user).exists():
        messages.error(request, 'Вы уже оставляли отзыв на это объявление.')
        return redirect('ad_detail', pk=ad.pk)

    if request.method == 'POST':
        form = ReviewForm(request.POST)
        if form.is_valid():
            review = form.save(commit=False)
            review.ad = ad
            review.author = request.user
            review.save()
            messages.success(request, 'Спасибо за отзыв.')
            return redirect('ad_detail', pk=ad.pk)
    else:
        form = ReviewForm()
    return render(request, 'myapp/review_form.html', {'form': form, 'ad': ad})


@user_passes_test(_is_moderator)
def moderation_queue(request):
    """Очередь модерации (пункт 5 ТЗ).

    До правок эта страница была открыта всем, включая неавторизованных.
    Теперь доступ только у пользователей с флагом is_staff.
    """
    pending = Ad.objects.filter(is_approved=False).select_related('owner')

    if request.method == 'POST':
        approved_ids = request.POST.getlist('approved_ads')
        updated = Ad.objects.filter(pk__in=approved_ids).update(is_approved=True)
        messages.success(request, f'Одобрено объявлений: {updated}.')
        return redirect('moderation_queue')

    return render(request, 'myapp/moderation.html', {'ads': pending})


def register(request):
    if request.method == 'POST':
        form = RegistrationForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            return redirect('home')
    else:
        form = RegistrationForm()
    return render(request, 'registration/register.html', {'form': form})


def user_login(request):
    error_message = None
    if request.method == 'POST':
        username = request.POST.get('username', '')
        password = request.POST.get('password', '')
        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            return redirect(request.GET.get('next') or 'home')
        error_message = 'Неверное имя пользователя или пароль.'
    return render(request, 'registration/login.html', {'error_message': error_message})
