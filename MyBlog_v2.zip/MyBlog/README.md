# Дипломный проект: Веб-сайт для аренды одежды

Константин Вохмянин — укажите своё имя и фамилию, если они пишутся иначе
логин на GitHub — укажите свой логин
e-mail — укажите свою почту

## О проекте

Бэкенд сайта для аренды одежды на Django. Реализованы все шесть функций
из технического задания:

1. **Размещение объявления** — описание, стоимость аренды, местоположение
   и контактная информация, фотография, категории, период доступности.
2. **Поиск объявлений** — по ключевым словам в заголовке и описании,
   по местоположению и по диапазону стоимости. Фильтры комбинируются.
3. **Редактирование и удаление** — только своих объявлений, с проверкой
   авторства на стороне сервера.
4. **Аутентификация** — регистрация, вход, выход. Размещать объявления
   и видеть контакты продавца могут только авторизованные пользователи.
5. **Модерация** — объявление публикуется только после одобрения.
   Очередь модерации доступна пользователям с флагом `is_staff`.
6. **Отзывы** — оценка от 1 до 5 и текст. Один отзыв на объявление
   от одного пользователя, на своё объявление отзыв оставить нельзя.

## Стек

- Python 3.12, Django 6.1
- PostgreSQL 16
- Docker и Docker Compose
- unittest (встроенный тест-раннер Django)

## Запуск через Docker

```bash
cp .env.example .env
# откройте .env и задайте DJANGO_SECRET_KEY и пароль базы
docker compose up --build
```

Сайт будет доступен на http://localhost:8000

Создать администратора (он же модератор):

```bash
docker compose exec web python manage.py createsuperuser
```

## Запуск без Docker

Понадобится установленный и запущенный PostgreSQL.

```bash
python -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env            # задайте параметры своей базы
python manage.py migrate
python manage.py createsuperuser
python manage.py runserver
```

## Тесты

29 тестов покрывают все шесть функций ТЗ.

```bash
docker compose exec web python manage.py test
```

Или локально, без поднятия PostgreSQL:

```bash
DB_ENGINE=django.db.backends.sqlite3 DB_NAME=test.sqlite3 python manage.py test
```

## Переменные окружения

Все настройки окружения читаются из `.env`, в репозиторий этот файл
не попадает. Образец — в `.env.example`.

| Переменная | Назначение |
| --- | --- |
| `DJANGO_SECRET_KEY` | Секретный ключ Django |
| `DJANGO_DEBUG` | Режим отладки, в боевом режиме `False` |
| `DJANGO_ALLOWED_HOSTS` | Список разрешённых хостов через запятую |
| `DB_ENGINE` | Движок базы, по умолчанию PostgreSQL |
| `DB_NAME`, `DB_USER`, `DB_PASSWORD`, `DB_HOST`, `DB_PORT` | Параметры подключения к базе |

## Структура

```
MyBlog/
├── MyBlog/              настройки проекта, корневые маршруты, wsgi/asgi
├── myapp/
│   ├── models.py        Ad, Category, Review
│   ├── forms.py         формы объявления, поиска, отзыва, регистрации
│   ├── views.py         представления всех шести функций
│   ├── urls.py          маршруты приложения
│   ├── admin.py         админка с массовым одобрением объявлений
│   ├── tests.py         29 unit-тестов
│   └── templates/       шаблоны
├── Dockerfile
├── docker-compose.yml
├── requirements.txt
└── .env.example
```
